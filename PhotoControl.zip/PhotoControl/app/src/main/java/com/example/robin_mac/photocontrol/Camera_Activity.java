package com.example.robin_mac.photocontrol;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Camera;
import android.media.Image;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Camera_Activity extends AppCompatActivity {

    private android.hardware.Camera mCamera;
    private CameraPreview mPreview;
    private android.hardware.Camera.PictureCallback mPicture = new android.hardware.Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, android.hardware.Camera camera) {

                File pictureFile = getOutputMediaFile();
                if(pictureFile == null){
                    Log.d("TAG", "Error creating media file, check storage permissions: ");
                    return;
                }

                try{
                    FileOutputStream fileOutputStream = new FileOutputStream(pictureFile);
                    fileOutputStream.write(data);
                    fileOutputStream.close();
                }
                catch(FileNotFoundException e){
                    Log.d("Tag", "FileNotFound" + e.getMessage());

                }
                catch (IOException e){
                    Log.d("Tag", "Error accessing file: " + e.getMessage());
                }

        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_);


        mCamera = getCameraInstance();

        mPreview = new CameraPreview(this,mCamera);
        FrameLayout preview = (FrameLayout)findViewById(R.id.fl_Preview);
        preview.addView(mPreview);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);



    }

    private boolean checkCameraHardware(Context context){
        if(context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
            return true;
        }
        else{
            return false;
        }
    }

    public static android.hardware.Camera getCameraInstance(){
        android.hardware.Camera camera = null;
        try{
            camera = android.hardware.Camera.open();
        }
        catch (Exception e){

        }
        return camera;
    }

    private static Uri getOutMediaFileUri(int type){
        return Uri.fromFile(getOutputMediaFile());
    }

    private static File getOutputMediaFile(){
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyCameraApp");

        if(! mediaStorageDir.exists()){
            if(! mediaStorageDir.mkdirs()) {
                Log.d("DIR", "Faied to create directory");
                return null;
            }
        }

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        File mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");

        return mediaFile;
    }

    public void TakePICOnCLICK(View view){
        mCamera.takePicture(null,null, mPicture);
        Toast t = Toast.makeText(getApplicationContext(), "click", Toast.LENGTH_LONG);

        t.show();

    }


}

